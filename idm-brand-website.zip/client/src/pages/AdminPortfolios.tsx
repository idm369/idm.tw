import { Link } from "wouter";
import { Plus, Eye, Edit, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import DashboardLayout from "@/components/DashboardLayout";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function AdminPortfolios() {
  const { data: portfolios, isLoading } = trpc.portfolio.list.useQuery();

  // TODO: 實作刪除功能
  const handleDelete = (id: number) => {
    toast.info("刪除功能開發中");
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">作品集管理</h1>
            <p className="text-muted-foreground">管理所有作品集項目</p>
          </div>
          <Link href="/admin/portfolios/new">
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              新增作品
            </Button>
          </Link>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 gap-4">
            {[...Array(3)].map((_, i) => (
              <Card key={i}>
                <CardContent className="pt-6">
                  <div className="h-6 bg-muted rounded animate-pulse" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : portfolios && portfolios.length > 0 ? (
          <div className="grid grid-cols-1 gap-4">
            {portfolios.map((portfolio) => {
              const images = portfolio.images ? JSON.parse(portfolio.images) : [];
              const coverImage = portfolio.coverImage || (images.length > 0 ? images[0] : null);

              return (
                <Card key={portfolio.id}>
                  <CardContent className="pt-6">
                    <div className="flex items-start gap-4">
                      {/* Thumbnail */}
                      <div className="flex-shrink-0 w-24 h-24 rounded-lg overflow-hidden bg-muted">
                        {coverImage ? (
                          <img
                            src={coverImage}
                            alt={portfolio.title}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-primary/20 to-accent/20">
                            <span className="text-xs font-bold text-primary/40">IDM</span>
                          </div>
                        )}
                      </div>

                      {/* Info */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-4 mb-2">
                          <div className="flex-1 min-w-0">
                            <h3 className="text-lg font-semibold truncate">{portfolio.title}</h3>
                            {portfolio.description && (
                              <p className="text-sm text-muted-foreground line-clamp-2 mt-1">
                                {portfolio.description}
                              </p>
                            )}
                          </div>
                          <div className="flex items-center gap-2">
                            {portfolio.published ? (
                              <Badge variant="outline">已發布</Badge>
                            ) : (
                              <Badge variant="secondary">草稿</Badge>
                            )}
                            {portfolio.featured && (
                              <Badge variant="default">精選</Badge>
                            )}
                          </div>
                        </div>

                        <div className="flex items-center gap-4 text-sm text-muted-foreground mt-3">
                          {portfolio.category && (
                            <span className="px-2 py-1 bg-muted rounded text-xs">
                              {portfolio.category}
                            </span>
                          )}
                          <div className="flex items-center gap-1">
                            <Eye className="h-3 w-3" />
                            <span>{portfolio.viewCount || 0} 次瀏覽</span>
                          </div>
                          <span>
                            {new Date(portfolio.createdAt).toLocaleDateString('zh-TW')}
                          </span>
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="flex items-center gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => toast.info("編輯功能開發中")}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDelete(portfolio.id)}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        ) : (
          <Card>
            <CardContent className="pt-12 pb-12 text-center">
              <p className="text-muted-foreground mb-4">尚無作品集項目</p>
              <Link href="/admin/portfolios/new">
                <Button>
                  <Plus className="mr-2 h-4 w-4" />
                  新增第一個作品
                </Button>
              </Link>
            </CardContent>
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
}
