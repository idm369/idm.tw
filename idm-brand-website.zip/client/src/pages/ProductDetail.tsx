import { useRoute, Link } from "wouter";
import { Eye, Calendar, ArrowLeft, Package } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { trpc } from "@/lib/trpc";
import { Streamdown } from "streamdown";
import { toast } from "sonner";

export default function ProductDetail() {
  const [, params] = useRoute("/shop/:slug");
  const slug = params?.slug || "";

  const { data: product, isLoading } = trpc.product.getBySlug.useQuery({ slug });

  const formatPrice = (price: number) => {
    return `NT$ ${(price / 100).toLocaleString('zh-TW')}`;
  };

  const handleAddToCart = () => {
    // TODO: 實作購物車功能
    toast.info("購物車功能開發中");
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 py-16">
          <div className="container">
            <div className="max-w-6xl mx-auto">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="aspect-square bg-muted animate-pulse rounded-lg" />
                <div className="space-y-4">
                  <div className="h-12 bg-muted animate-pulse rounded" />
                  <div className="h-6 bg-muted animate-pulse rounded w-2/3" />
                  <div className="h-8 bg-muted animate-pulse rounded w-1/3" />
                </div>
              </div>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 py-16">
          <div className="container text-center">
            <h1 className="text-4xl font-bold mb-4">商品不存在</h1>
            <Link href="/shop">
              <Button>
                <ArrowLeft className="mr-2 h-4 w-4" />
                返回商店
              </Button>
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  const images = product.images ? JSON.parse(product.images) : [];
  const allImages = [product.coverImage, ...images].filter(Boolean);
  const tags = product.tags ? JSON.parse(product.tags) : [];
  const specifications = product.specifications ? JSON.parse(product.specifications) : {};
  const hasDiscount = product.originalPrice && product.originalPrice > product.price;

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1">
        {/* Back Button */}
        <section className="py-6 border-b border-border">
          <div className="container">
            <Link href="/shop">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="mr-2 h-4 w-4" />
                返回商店
              </Button>
            </Link>
          </div>
        </section>

        {/* Product Details */}
        <section className="py-12">
          <div className="container">
            <div className="max-w-6xl mx-auto">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                {/* Images */}
                <div className="space-y-4">
                  {allImages.length > 0 ? (
                    <>
                      <div className="aspect-square rounded-lg overflow-hidden bg-muted">
                        <img
                          src={allImages[0]}
                          alt={product.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      {allImages.length > 1 && (
                        <div className="grid grid-cols-4 gap-2">
                          {allImages.slice(1, 5).map((image, index) => (
                            <div key={index} className="aspect-square rounded-lg overflow-hidden bg-muted">
                              <img
                                src={image}
                                alt={`${product.name} - ${index + 2}`}
                                className="w-full h-full object-cover"
                              />
                            </div>
                          ))}
                        </div>
                      )}
                    </>
                  ) : (
                    <div className="aspect-square rounded-lg bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
                      <Package className="h-32 w-32 text-primary/40" />
                    </div>
                  )}
                </div>

                {/* Info */}
                <div className="space-y-6">
                  {/* Title & Category */}
                  <div>
                    {product.category && (
                      <span className="inline-block px-3 py-1 bg-primary/10 text-primary rounded-full text-sm mb-3">
                        {product.category}
                      </span>
                    )}
                    <h1 className="text-3xl md:text-4xl font-bold mb-3">{product.name}</h1>
                    {product.description && (
                      <p className="text-lg text-muted-foreground">{product.description}</p>
                    )}
                  </div>

                  {/* Meta */}
                  <div className="flex items-center gap-4 text-sm text-muted-foreground pb-6 border-b border-border">
                    <div className="flex items-center gap-1">
                      <Eye className="h-4 w-4" />
                      <span>{product.viewCount || 0} 次瀏覽</span>
                    </div>
                    {(product.soldCount ?? 0) > 0 && (
                      <span>已售出 {product.soldCount} 件</span>
                    )}
                  </div>

                  {/* Price */}
                  <div className="py-6 border-b border-border">
                    <div className="flex items-baseline gap-3 mb-2">
                      <span className="text-4xl font-bold text-primary">
                        {formatPrice(product.price)}
                      </span>
                      {hasDiscount && (
                        <span className="text-xl text-muted-foreground line-through">
                          {formatPrice(product.originalPrice!)}
                        </span>
                      )}
                    </div>
                    {product.sku && (
                      <p className="text-sm text-muted-foreground">SKU: {product.sku}</p>
                    )}
                  </div>

                  {/* Stock */}
                  <div className="py-4">
                    {(product.stock ?? 0) > 0 ? (
                      <p className="text-sm text-muted-foreground">
                        庫存: {product.stock} 件
                      </p>
                    ) : (
                      <p className="text-sm text-destructive font-semibold">已售完</p>
                    )}
                  </div>

                  {/* Actions */}
                  <div className="space-y-3">
                    <Button
                      size="lg"
                      className="w-full"
                      disabled={(product.stock ?? 0) === 0}
                      onClick={handleAddToCart}
                    >
                      加入購物車
                    </Button>
                  </div>

                  {/* Tags */}
                  {tags.length > 0 && (
                    <div className="pt-6 border-t border-border">
                      <div className="flex flex-wrap gap-2">
                        {tags.map((tag: string, index: number) => (
                          <span key={index} className="px-3 py-1 bg-muted text-sm rounded">
                            {tag}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Specifications */}
              {Object.keys(specifications).length > 0 && (
                <Card className="mt-12">
                  <CardContent className="pt-8">
                    <h3 className="text-2xl font-semibold mb-6">產品規格</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {Object.entries(specifications).map(([key, value]) => (
                        <div key={key} className="flex border-b border-border pb-3">
                          <span className="font-medium text-muted-foreground w-32">{key}</span>
                          <span className="flex-1">{String(value)}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Content */}
              {product.content && (
                <Card className="mt-8">
                  <CardContent className="pt-8 prose prose-slate max-w-none">
                    <h3 className="text-2xl font-semibold mb-6">產品詳情</h3>
                    <Streamdown>{product.content}</Streamdown>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
