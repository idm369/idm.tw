import { useRoute } from "wouter";
import { Eye, Calendar, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";
import { Streamdown } from "streamdown";

export default function PortfolioDetail() {
  const [, params] = useRoute("/portfolio/:slug");
  const slug = params?.slug || "";

  const { data: portfolio, isLoading } = trpc.portfolio.getBySlug.useQuery({ slug });

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 py-16">
          <div className="container">
            <div className="max-w-4xl mx-auto">
              <div className="aspect-video bg-muted animate-pulse rounded-lg mb-8" />
              <div className="h-12 bg-muted animate-pulse rounded mb-4" />
              <div className="h-6 bg-muted animate-pulse rounded w-2/3 mb-8" />
              <div className="space-y-4">
                <div className="h-4 bg-muted animate-pulse rounded" />
                <div className="h-4 bg-muted animate-pulse rounded" />
                <div className="h-4 bg-muted animate-pulse rounded w-3/4" />
              </div>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  if (!portfolio) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 py-16">
          <div className="container text-center">
            <h1 className="text-4xl font-bold mb-4">作品不存在</h1>
            <Link href="/portfolio">
              <Button>
                <ArrowLeft className="mr-2 h-4 w-4" />
                返回作品集
              </Button>
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  const images = portfolio.images ? JSON.parse(portfolio.images) : [];
  const tags = portfolio.tags ? JSON.parse(portfolio.tags) : [];

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1">
        {/* Back Button */}
        <section className="py-6 border-b border-border">
          <div className="container">
            <Link href="/portfolio">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="mr-2 h-4 w-4" />
                返回作品集
              </Button>
            </Link>
          </div>
        </section>

        {/* Hero Image */}
        <section className="py-8">
          <div className="container">
            <div className="max-w-5xl mx-auto">
              {portfolio.coverImage || images.length > 0 ? (
                <div className="aspect-video rounded-lg overflow-hidden bg-muted">
                  <img
                    src={portfolio.coverImage || images[0]}
                    alt={portfolio.title}
                    className="w-full h-full object-cover"
                  />
                </div>
              ) : (
                <div className="aspect-video rounded-lg bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
                  <span className="text-6xl font-bold text-primary/40">IDM</span>
                </div>
              )}
            </div>
          </div>
        </section>

        {/* Content */}
        <section className="py-8">
          <div className="container">
            <div className="max-w-4xl mx-auto">
              {/* Title & Meta */}
              <div className="mb-8">
                <h1 className="text-4xl md:text-5xl font-bold mb-4">{portfolio.title}</h1>
                
                <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground mb-6">
                  {portfolio.category && (
                    <span className="px-3 py-1 bg-primary/10 text-primary rounded-full">
                      {portfolio.category}
                    </span>
                  )}
                  <div className="flex items-center gap-1">
                    <Eye className="h-4 w-4" />
                    <span>{portfolio.viewCount || 0} 次瀏覽</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Calendar className="h-4 w-4" />
                    <span>{new Date(portfolio.createdAt).toLocaleDateString('zh-TW')}</span>
                  </div>
                </div>

                {portfolio.description && (
                  <p className="text-xl text-muted-foreground leading-relaxed">
                    {portfolio.description}
                  </p>
                )}
              </div>

              {/* Tags */}
              {tags.length > 0 && (
                <div className="flex flex-wrap gap-2 mb-8">
                  {tags.map((tag: string, index: number) => (
                    <span key={index} className="px-3 py-1 bg-muted text-sm rounded">
                      {tag}
                    </span>
                  ))}
                </div>
              )}

              {/* Content */}
              {portfolio.content && (
                <Card className="mb-8">
                  <CardContent className="pt-8 prose prose-slate max-w-none">
                    <Streamdown>{portfolio.content}</Streamdown>
                  </CardContent>
                </Card>
              )}

              {/* Video */}
              {portfolio.videoUrl && (
                <Card className="mb-8">
                  <CardContent className="pt-8">
                    <h3 className="text-2xl font-semibold mb-4">影片展示</h3>
                    <div className="aspect-video rounded-lg overflow-hidden bg-muted">
                      <iframe
                        src={portfolio.videoUrl}
                        className="w-full h-full"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowFullScreen
                      />
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Additional Images */}
              {images.length > 1 && (
                <Card>
                  <CardContent className="pt-8">
                    <h3 className="text-2xl font-semibold mb-6">更多圖片</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {images.slice(1).map((image: string, index: number) => (
                        <div key={index} className="aspect-video rounded-lg overflow-hidden bg-muted">
                          <img
                            src={image}
                            alt={`${portfolio.title} - ${index + 2}`}
                            className="w-full h-full object-cover"
                          />
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
