import { useState } from "react";
import { Link } from "wouter";
import { Eye } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { trpc } from "@/lib/trpc";

export default function Portfolio() {
  const [selectedCategory, setSelectedCategory] = useState<string | undefined>(undefined);
  
  const { data: portfolios, isLoading } = trpc.portfolio.list.useQuery({
    category: selectedCategory,
  });

  const categories = ["全部", "模組化設計", "工業風格", "創客專案", "客製化"];

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1">
        {/* Hero Section */}
        <section className="bg-muted/30 py-16">
          <div className="container">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">作品集</h1>
            <p className="text-xl text-muted-foreground max-w-2xl">
              探索我們的創意設計與製造案例，感受模組化、工業風格的獨特魅力
            </p>
          </div>
        </section>

        {/* Category Filter */}
        <section className="py-8 border-b border-border">
          <div className="container">
            <div className="flex flex-wrap gap-2">
              {categories.map((category) => (
                <Button
                  key={category}
                  variant={selectedCategory === (category === "全部" ? undefined : category) ? "default" : "outline"}
                  onClick={() => setSelectedCategory(category === "全部" ? undefined : category)}
                >
                  {category}
                </Button>
              ))}
            </div>
          </div>
        </section>

        {/* Portfolio Grid */}
        <section className="py-16">
          <div className="container">
            {isLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {[...Array(6)].map((_, i) => (
                  <Card key={i} className="overflow-hidden">
                    <div className="aspect-video bg-muted animate-pulse" />
                    <CardContent className="pt-6">
                      <div className="h-6 bg-muted rounded mb-2 animate-pulse" />
                      <div className="h-4 bg-muted rounded w-2/3 animate-pulse" />
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : portfolios && portfolios.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {portfolios.map((portfolio) => {
                  const images = portfolio.images ? JSON.parse(portfolio.images) : [];
                  const coverImage = portfolio.coverImage || (images.length > 0 ? images[0] : null);
                  
                  return (
                    <Link key={portfolio.id} href={`/portfolio/${portfolio.slug}`}>
                        <Card className="overflow-hidden border-border hover:border-primary transition-all hover:shadow-lg h-full">
                          <div className="aspect-video bg-muted overflow-hidden">
                            {coverImage ? (
                              <img
                                src={coverImage}
                                alt={portfolio.title}
                                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                              />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-primary/20 to-accent/20">
                                <span className="text-4xl font-bold text-primary/40">IDM</span>
                              </div>
                            )}
                          </div>
                          <CardContent className="pt-6">
                            <h3 className="text-xl font-semibold mb-2 group-hover:text-primary transition-colors line-clamp-2">
                              {portfolio.title}
                            </h3>
                            {portfolio.description && (
                              <p className="text-muted-foreground text-sm mb-4 line-clamp-2">
                                {portfolio.description}
                              </p>
                            )}
                            <div className="flex items-center justify-between text-sm text-muted-foreground">
                              {portfolio.category && (
                                <span className="px-2 py-1 bg-muted rounded text-xs">
                                  {portfolio.category}
                                </span>
                              )}
                              <div className="flex items-center gap-1">
                                <Eye className="h-4 w-4" />
                                <span>{portfolio.viewCount || 0}</span>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                    </Link>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-16">
                <p className="text-xl text-muted-foreground">目前沒有作品</p>
              </div>
            )}
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
