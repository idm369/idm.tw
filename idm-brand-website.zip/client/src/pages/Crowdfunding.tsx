import { Link } from "wouter";
import { Users, Target, TrendingUp } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { trpc } from "@/lib/trpc";

export default function Crowdfunding() {
  const { data: projects, isLoading } = trpc.crowdfunding.list.useQuery();

  const formatAmount = (amount: number) => {
    return `NT$ ${(amount / 100).toLocaleString('zh-TW')}`;
  };

  const getStatusBadge = (status: string) => {
    const statusMap: Record<string, { label: string; variant: "default" | "secondary" | "destructive" | "outline" }> = {
      draft: { label: "草稿", variant: "secondary" },
      active: { label: "進行中", variant: "default" },
      funded: { label: "已達標", variant: "outline" },
      completed: { label: "已完成", variant: "outline" },
      cancelled: { label: "已取消", variant: "destructive" },
    };
    return statusMap[status] || { label: status, variant: "secondary" };
  };

  const calculateProgress = (current: number, goal: number) => {
    return Math.min((current / goal) * 100, 100);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1">
        {/* Hero Section */}
        <section className="bg-gradient-to-br from-primary via-secondary to-accent text-primary-foreground py-20">
          <div className="container">
            <div className="max-w-3xl">
              <h1 className="text-4xl md:text-5xl font-bold mb-4">募資項目</h1>
              <p className="text-xl text-primary-foreground/90 leading-relaxed">
                參與我們的創新專案，一起實現更多創意想法。每一個專案都是從點子到實踐的旅程。
              </p>
            </div>
          </div>
        </section>

        {/* Projects Grid */}
        <section className="py-16">
          <div className="container">
            {isLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {[...Array(3)].map((_, i) => (
                  <Card key={i} className="overflow-hidden">
                    <div className="aspect-video bg-muted animate-pulse" />
                    <CardContent className="pt-6">
                      <div className="h-6 bg-muted rounded mb-2 animate-pulse" />
                      <div className="h-4 bg-muted rounded w-2/3 animate-pulse" />
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : projects && projects.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {projects.map((project) => {
                  const images = project.images ? JSON.parse(project.images) : [];
                  const coverImage = project.coverImage || (images.length > 0 ? images[0] : null);
                  const progress = calculateProgress(project.currentAmount ?? 0, project.goalAmount);
                  const statusBadge = getStatusBadge(project.status ?? 'draft');
                  
                  return (
                    <Link key={project.id} href={`/crowdfunding/${project.slug}`}>
                        <Card className="overflow-hidden border-border hover:border-primary transition-all hover:shadow-lg h-full flex flex-col">
                          <div className="aspect-video bg-muted overflow-hidden relative">
                            {coverImage ? (
                              <img
                                src={coverImage}
                                alt={project.title}
                                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                              />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-primary/20 to-accent/20">
                                <Target className="h-16 w-16 text-primary/40" />
                              </div>
                            )}
                            <div className="absolute top-4 right-4">
                              <Badge variant={statusBadge.variant}>{statusBadge.label}</Badge>
                            </div>
                          </div>
                          <CardContent className="pt-6 flex-1 flex flex-col">
                            <h3 className="text-xl font-semibold mb-2 group-hover:text-primary transition-colors line-clamp-2">
                              {project.title}
                            </h3>
                            {project.subtitle && (
                              <p className="text-muted-foreground text-sm mb-4 line-clamp-2 flex-1">
                                {project.subtitle}
                              </p>
                            )}
                            
                            <div className="space-y-4 mt-auto">
                              {/* Progress Bar */}
                              <div className="space-y-2">
                                <Progress value={progress} className="h-2" />
                                <div className="flex justify-between text-sm">
                                  <span className="font-semibold text-primary">
                                    {formatAmount(project.currentAmount ?? 0)}
                                  </span>
                                  <span className="text-muted-foreground">
                                    目標 {formatAmount(project.goalAmount)}
                                  </span>
                                </div>
                              </div>

                              {/* Stats */}
                              <div className="flex items-center justify-between text-sm text-muted-foreground pt-4 border-t border-border">
                                <div className="flex items-center gap-1">
                                  <Users className="h-4 w-4" />
                                  <span>{project.backerCount ?? 0} 人贊助</span>
                                </div>
                                <div className="flex items-center gap-1">
                                  <TrendingUp className="h-4 w-4" />
                                  <span>{Math.round(progress)}%</span>
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                    </Link>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-16">
                <Target className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                <p className="text-xl text-muted-foreground">目前沒有募資項目</p>
              </div>
            )}
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
