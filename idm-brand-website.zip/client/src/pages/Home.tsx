import { Link } from "wouter";
import { ArrowRight, Package, Lightbulb, Wrench } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import SEO from "@/components/SEO";

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col">
      <SEO
        title="首頁"
        description="IDM 工作室 - 想像無限，勇於實踐。從點子到設計，從設計到製造，我們提供完整的創意實踐解決方案。"
        keywords="IDM, 工作室, 創意設計, 模組化設計, 工業風格, 創客"
      />
      <Header />
      
      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative bg-gradient-to-br from-primary via-secondary to-accent text-primary-foreground">
          <div className="container py-24 md:py-32 lg:py-40">
            <div className="max-w-3xl">
              <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold tracking-tight mb-6">
                想像無限，<br />勇於實踐
              </h1>
              <p className="text-xl md:text-2xl text-primary-foreground/90 mb-8 leading-relaxed">
                創意，從「敢想」開始。每一個偉大的成就，都源於一個最初的點子。
              </p>
              <div className="flex flex-wrap gap-4">
                <Link href="/portfolio">
                  <Button size="lg" variant="secondary" className="text-base">
                    探索作品集
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </Link>
                <Link href="/shop">
                  <Button size="lg" variant="outline" className="text-base bg-transparent border-primary-foreground text-primary-foreground hover:bg-primary-foreground/10">
                    前往商店
                  </Button>
                </Link>
              </div>
            </div>
          </div>
          
          {/* Decorative element */}
          <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-background to-transparent"></div>
        </section>

        {/* Core Values */}
        <section className="py-20 bg-background">
          <div className="container">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">我們的核心能力</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                從點子到設計，從設計到製造，我們提供完整的創意實踐解決方案
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <Card className="border-border hover:shadow-lg transition-shadow">
                <CardContent className="pt-8 pb-8 text-center">
                  <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 text-primary mb-6">
                    <Lightbulb className="h-8 w-8" />
                  </div>
                  <h3 className="text-xl font-semibold mb-3">點子</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    激發創意思維，將抽象概念轉化為具體可行的方案
                  </p>
                </CardContent>
              </Card>

              <Card className="border-border hover:shadow-lg transition-shadow">
                <CardContent className="pt-8 pb-8 text-center">
                  <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-accent/10 text-accent mb-6">
                    <Package className="h-8 w-8" />
                  </div>
                  <h3 className="text-xl font-semibold mb-3">設計</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    融合工業美學與機能性，打造兼具實用與美感的設計
                  </p>
                </CardContent>
              </Card>

              <Card className="border-border hover:shadow-lg transition-shadow">
                <CardContent className="pt-8 pb-8 text-center">
                  <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-secondary/10 text-secondary mb-6">
                    <Wrench className="h-8 w-8" />
                  </div>
                  <h3 className="text-xl font-semibold mb-3">製造</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    運用精密工藝與創客精神，將設計轉化為實體產品
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Quick Navigation */}
        <section className="py-20 bg-muted/30">
          <div className="container">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {/* Portfolio */}
              <Link href="/portfolio">
                <a className="group block">
                  <Card className="h-full border-border hover:border-primary transition-all hover:shadow-lg">
                    <CardContent className="pt-8 pb-8">
                      <div className="aspect-video bg-gradient-to-br from-primary/20 to-accent/20 rounded-md mb-6 flex items-center justify-center">
                        <Package className="h-16 w-16 text-primary" />
                      </div>
                      <h3 className="text-2xl font-semibold mb-3 group-hover:text-primary transition-colors">
                        作品集
                      </h3>
                      <p className="text-muted-foreground mb-4">
                        探索我們的創意設計與製造案例，感受模組化、工業風格的獨特魅力
                      </p>
                      <div className="flex items-center text-primary font-medium">
                        查看更多
                        <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                      </div>
                    </CardContent>
                  </Card>
                </a>
              </Link>

              {/* Shop */}
              <Link href="/shop">
                <a className="group block">
                  <Card className="h-full border-border hover:border-primary transition-all hover:shadow-lg">
                    <CardContent className="pt-8 pb-8">
                      <div className="aspect-video bg-gradient-to-br from-accent/20 to-secondary/20 rounded-md mb-6 flex items-center justify-center">
                        <Package className="h-16 w-16 text-accent" />
                      </div>
                      <h3 className="text-2xl font-semibold mb-3 group-hover:text-primary transition-colors">
                        線上商店
                      </h3>
                      <p className="text-muted-foreground mb-4">
                        選購我們精心設計的產品，體驗工業美學與實用性的完美結合
                      </p>
                      <div className="flex items-center text-primary font-medium">
                        立即選購
                        <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                      </div>
                    </CardContent>
                  </Card>
                </a>
              </Link>

              {/* Crowdfunding */}
              <Link href="/crowdfunding">
                <a className="group block">
                  <Card className="h-full border-border hover:border-primary transition-all hover:shadow-lg">
                    <CardContent className="pt-8 pb-8">
                      <div className="aspect-video bg-gradient-to-br from-secondary/20 to-primary/20 rounded-md mb-6 flex items-center justify-center">
                        <Lightbulb className="h-16 w-16 text-secondary" />
                      </div>
                      <h3 className="text-2xl font-semibold mb-3 group-hover:text-primary transition-colors">
                        募資項目
                      </h3>
                      <p className="text-muted-foreground mb-4">
                        參與我們的創新專案，一起實現更多創意想法
                      </p>
                      <div className="flex items-center text-primary font-medium">
                        探索專案
                        <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                      </div>
                    </CardContent>
                  </Card>
                </a>
              </Link>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-primary text-primary-foreground">
          <div className="container text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              準備好實踐你的創意了嗎？
            </h2>
            <p className="text-xl text-primary-foreground/90 mb-8 max-w-2xl mx-auto">
              無論是尋找靈感、選購產品，或是參與募資專案，我們都在這裡支持你
            </p>
            <Link href="/contact">
              <Button size="lg" variant="secondary" className="text-base">
                聯繫我們
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
