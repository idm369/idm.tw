import { Lightbulb, Package, Wrench, Target } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { APP_TITLE } from "@/const";

export default function About() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1">
        {/* Hero Section */}
        <section className="bg-gradient-to-br from-primary via-secondary to-accent text-primary-foreground py-20">
          <div className="container">
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-6">關於 {APP_TITLE}</h1>
              <p className="text-xl text-primary-foreground/90 leading-relaxed">
                我們是一個專注於創意實踐的工作室，致力於將想像轉化為現實
              </p>
            </div>
          </div>
        </section>

        {/* Core Philosophy */}
        <section className="py-20 bg-background">
          <div className="container">
            <div className="max-w-4xl mx-auto">
              <div className="text-center mb-16">
                <h2 className="text-3xl md:text-4xl font-bold mb-6">核心精神</h2>
                <div className="text-5xl md:text-6xl font-bold mb-6 text-primary">
                  想像無限，勇於實踐
                </div>
                <p className="text-xl text-muted-foreground leading-relaxed">
                  創意，從「敢想」開始。每一個偉大的成就，都源於一個最初的點子。
                  我們相信，只要勇於實踐，任何想像都能成為現實。
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Core Capabilities */}
        <section className="py-20 bg-muted/30">
          <div className="container">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center">核心能力</h2>
              <div className="space-y-12">
                {/* Idea */}
                <Card>
                  <CardContent className="pt-8 pb-8">
                    <div className="flex items-start gap-6">
                      <div className="flex-shrink-0 w-16 h-16 rounded-full bg-primary/10 text-primary flex items-center justify-center">
                        <Lightbulb className="h-8 w-8" />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-2xl font-semibold mb-3">點子</h3>
                        <p className="text-muted-foreground leading-relaxed">
                          我們擅長激發創意思維，透過腦力激盪與系統化的方法論，將抽象的概念轉化為具體可行的方案。
                          無論是產品創新、服務設計，或是商業模式的重新思考，我們都能提供專業的創意諮詢。
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Design */}
                <Card>
                  <CardContent className="pt-8 pb-8">
                    <div className="flex items-start gap-6">
                      <div className="flex-shrink-0 w-16 h-16 rounded-full bg-accent/10 text-accent flex items-center justify-center">
                        <Package className="h-8 w-8" />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-2xl font-semibold mb-3">設計</h3>
                        <p className="text-muted-foreground leading-relaxed">
                          融合工業美學與機能性，我們的設計不僅美觀，更注重實用性與使用者體驗。
                          從產品外觀到結構設計，從材質選擇到製程規劃，每個細節都經過精心考量，
                          打造兼具美感與功能的設計作品。
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Manufacturing */}
                <Card>
                  <CardContent className="pt-8 pb-8">
                    <div className="flex items-start gap-6">
                      <div className="flex-shrink-0 w-16 h-16 rounded-full bg-secondary/10 text-secondary flex items-center justify-center">
                        <Wrench className="h-8 w-8" />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-2xl font-semibold mb-3">製造</h3>
                        <p className="text-muted-foreground leading-relaxed">
                          運用精密工藝與創客精神，我們將設計轉化為實體產品。
                          結合傳統工藝與現代技術，從原型製作到小批量生產，
                          我們提供完整的製造解決方案，確保每個產品都達到最高品質標準。
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        {/* Design Philosophy */}
        <section className="py-20 bg-background">
          <div className="container">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center">設計理念</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <Card>
                  <CardContent className="pt-8 pb-8 text-center">
                    <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 text-primary mb-4">
                      <Package className="h-8 w-8" />
                    </div>
                    <h3 className="text-xl font-semibold mb-3">模組化</h3>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      靈活組合，無限可能。模組化設計讓產品更具擴展性與適應性。
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="pt-8 pb-8 text-center">
                    <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-accent/10 text-accent mb-4">
                      <Wrench className="h-8 w-8" />
                    </div>
                    <h3 className="text-xl font-semibold mb-3">工業風格</h3>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      簡約而不簡單，工業美學展現力量與精準的完美結合。
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="pt-8 pb-8 text-center">
                    <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-secondary/10 text-secondary mb-4">
                      <Target className="h-8 w-8" />
                    </div>
                    <h3 className="text-xl font-semibold mb-3">創客精神</h3>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      動手實踐，勇於嘗試。我們鼓勵創新與實驗，將想法付諸行動。
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        {/* Values */}
        <section className="py-20 bg-muted/30">
          <div className="container">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center">我們的價值觀</h2>
              <div className="space-y-8">
                <div className="border-l-4 border-primary pl-6">
                  <h3 className="text-xl font-semibold mb-2">創新思維</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    我們不滿足於現狀，持續探索新的可能性，挑戰傳統思維框架。
                  </p>
                </div>
                <div className="border-l-4 border-accent pl-6">
                  <h3 className="text-xl font-semibold mb-2">品質至上</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    每個細節都經過精心打磨，我們堅持提供最高品質的產品與服務。
                  </p>
                </div>
                <div className="border-l-4 border-secondary pl-6">
                  <h3 className="text-xl font-semibold mb-2">永續發展</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    在創新的同時，我們也關注環境永續，致力於創造對社會有益的價值。
                  </p>
                </div>
                <div className="border-l-4 border-primary pl-6">
                  <h3 className="text-xl font-semibold mb-2">開放協作</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    我們相信集體智慧的力量，樂於與各界夥伴合作，共同創造更大價值。
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
