import { LayoutDashboard, Package, ShoppingBag, Target, MessageSquare, FileText } from "lucide-react";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import DashboardLayout from "@/components/DashboardLayout";
import { trpc } from "@/lib/trpc";

export default function Admin() {
  const { data: portfolios } = trpc.portfolio.list.useQuery();
  const { data: products } = trpc.product.list.useQuery();
  const { data: projects } = trpc.crowdfunding.list.useQuery();

  const stats = [
    {
      title: "作品集",
      value: portfolios?.length || 0,
      icon: Package,
      href: "/admin/portfolios",
      color: "text-primary",
    },
    {
      title: "商品",
      value: products?.length || 0,
      icon: ShoppingBag,
      href: "/admin/products",
      color: "text-accent",
    },
    {
      title: "募資項目",
      value: projects?.length || 0,
      icon: Target,
      href: "/admin/crowdfunding",
      color: "text-secondary",
    },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-8">
        <div>
          <h1 className="text-3xl font-bold mb-2">管理後台</h1>
          <p className="text-muted-foreground">管理網站內容與設定</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {stats.map((stat) => (
            <Link key={stat.title} href={stat.href}>
              <Card className="hover:border-primary transition-colors cursor-pointer">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    {stat.title}
                  </CardTitle>
                  <stat.icon className={`h-4 w-4 ${stat.color}`} />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">{stat.value}</div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>

        {/* Quick Actions */}
        <div>
          <h2 className="text-xl font-semibold mb-4">快速操作</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <Link href="/admin/portfolios/new">
              <Card className="hover:bg-muted/50 transition-colors cursor-pointer">
                <CardContent className="pt-6 flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-primary/10 text-primary flex items-center justify-center">
                    <Package className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="font-semibold">新增作品</h3>
                    <p className="text-sm text-muted-foreground">建立新的作品集項目</p>
                  </div>
                </CardContent>
              </Card>
            </Link>

            <Link href="/admin/products/new">
              <Card className="hover:bg-muted/50 transition-colors cursor-pointer">
                <CardContent className="pt-6 flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-accent/10 text-accent flex items-center justify-center">
                    <ShoppingBag className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="font-semibold">新增商品</h3>
                    <p className="text-sm text-muted-foreground">建立新的商品項目</p>
                  </div>
                </CardContent>
              </Card>
            </Link>

            <Link href="/admin/crowdfunding/new">
              <Card className="hover:bg-muted/50 transition-colors cursor-pointer">
                <CardContent className="pt-6 flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-secondary/10 text-secondary flex items-center justify-center">
                    <Target className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="font-semibold">新增募資項目</h3>
                    <p className="text-sm text-muted-foreground">建立新的募資專案</p>
                  </div>
                </CardContent>
              </Card>
            </Link>
          </div>
        </div>

        {/* Info Card */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              使用說明
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm text-muted-foreground">
            <p>• 點擊上方統計卡片可快速進入各項目管理頁面</p>
            <p>• 使用快速操作區塊可直接建立新內容</p>
            <p>• 所有內容都支援草稿功能，未發布的內容不會在前台顯示</p>
            <p>• 圖片上傳後會自動儲存至雲端儲存空間</p>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
