import { useRoute, Link } from "wouter";
import { Users, Target, TrendingUp, ArrowLeft, Calendar, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { trpc } from "@/lib/trpc";
import { Streamdown } from "streamdown";

export default function CrowdfundingDetail() {
  const [, params] = useRoute("/crowdfunding/:slug");
  const slug = params?.slug || "";

  const { data: project, isLoading } = trpc.crowdfunding.getBySlug.useQuery({ slug });

  const formatAmount = (amount: number) => {
    return `NT$ ${(amount / 100).toLocaleString('zh-TW')}`;
  };

  const getStatusBadge = (status: string) => {
    const statusMap: Record<string, { label: string; variant: "default" | "secondary" | "destructive" | "outline" }> = {
      draft: { label: "草稿", variant: "secondary" },
      active: { label: "進行中", variant: "default" },
      funded: { label: "已達標", variant: "outline" },
      completed: { label: "已完成", variant: "outline" },
      cancelled: { label: "已取消", variant: "destructive" },
    };
    return statusMap[status] || { label: status, variant: "secondary" };
  };

  const calculateProgress = (current: number, goal: number) => {
    return Math.min((current / goal) * 100, 100);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 py-16">
          <div className="container">
            <div className="max-w-6xl mx-auto">
              <div className="aspect-video bg-muted animate-pulse rounded-lg mb-8" />
              <div className="h-12 bg-muted animate-pulse rounded mb-4" />
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  if (!project) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 py-16">
          <div className="container text-center">
            <h1 className="text-4xl font-bold mb-4">專案不存在</h1>
            <Link href="/crowdfunding">
              <Button>
                <ArrowLeft className="mr-2 h-4 w-4" />
                返回募資項目
              </Button>
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  const images = project.images ? JSON.parse(project.images) : [];
  const coverImage = project.coverImage || (images.length > 0 ? images[0] : null);
  const rewards = project.rewards ? JSON.parse(project.rewards) : [];
  const updates = project.updates ? JSON.parse(project.updates) : [];
  const faq = project.faq ? JSON.parse(project.faq) : [];
  const progress = calculateProgress(project.currentAmount ?? 0, project.goalAmount);
  const statusBadge = getStatusBadge(project.status ?? 'draft');

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1">
        {/* Back Button */}
        <section className="py-6 border-b border-border">
          <div className="container">
            <Link href="/crowdfunding">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="mr-2 h-4 w-4" />
                返回募資項目
              </Button>
            </Link>
          </div>
        </section>

        {/* Hero */}
        <section className="py-8">
          <div className="container">
            <div className="max-w-6xl mx-auto">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Left: Image & Video */}
                <div className="lg:col-span-2 space-y-6">
                  {coverImage ? (
                    <div className="aspect-video rounded-lg overflow-hidden bg-muted">
                      <img
                        src={coverImage}
                        alt={project.title}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  ) : (
                    <div className="aspect-video rounded-lg bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
                      <Target className="h-32 w-32 text-primary/40" />
                    </div>
                  )}

                  {project.videoUrl && (
                    <div className="aspect-video rounded-lg overflow-hidden bg-muted">
                      <iframe
                        src={project.videoUrl}
                        className="w-full h-full"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowFullScreen
                      />
                    </div>
                  )}
                </div>

                {/* Right: Stats & CTA */}
                <div className="space-y-6">
                  <Card>
                    <CardContent className="pt-6 space-y-6">
                      <div>
                        <Badge variant={statusBadge.variant} className="mb-4">{statusBadge.label}</Badge>
                        <h1 className="text-2xl font-bold mb-2">{project.title}</h1>
                        {project.subtitle && (
                          <p className="text-muted-foreground">{project.subtitle}</p>
                        )}
                      </div>

                      {/* Progress */}
                      <div className="space-y-3">
                        <div className="text-3xl font-bold text-primary">
                          {formatAmount(project.currentAmount ?? 0)}
                        </div>
                        <Progress value={progress} className="h-3" />
                        <div className="flex justify-between text-sm text-muted-foreground">
                          <span>目標 {formatAmount(project.goalAmount)}</span>
                          <span>{Math.round(progress)}%</span>
                        </div>
                      </div>

                      {/* Stats */}
                      <div className="grid grid-cols-2 gap-4 pt-4 border-t border-border">
                        <div>
                          <div className="flex items-center gap-2 text-muted-foreground mb-1">
                            <Users className="h-4 w-4" />
                            <span className="text-sm">贊助人數</span>
                          </div>
                          <div className="text-2xl font-semibold">{project.backerCount ?? 0}</div>
                        </div>
                        <div>
                          <div className="flex items-center gap-2 text-muted-foreground mb-1">
                            <Calendar className="h-4 w-4" />
                            <span className="text-sm">結束日期</span>
                          </div>
                          <div className="text-sm font-semibold">
                            {project.endDate ? new Date(project.endDate).toLocaleDateString('zh-TW') : '未設定'}
                          </div>
                        </div>
                      </div>

                      {/* CTA */}
                      {project.externalUrl && (
                        <Button size="lg" className="w-full" asChild>
                          <a href={project.externalUrl} target="_blank" rel="noopener noreferrer">
                            前往募資平台
                            <ExternalLink className="ml-2 h-4 w-4" />
                          </a>
                        </Button>
                      )}
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Content Tabs */}
        <section className="py-12">
          <div className="container">
            <div className="max-w-6xl mx-auto">
              <Tabs defaultValue="story" className="w-full">
                <TabsList className="grid w-full grid-cols-4">
                  <TabsTrigger value="story">專案故事</TabsTrigger>
                  <TabsTrigger value="rewards">回饋方案</TabsTrigger>
                  <TabsTrigger value="updates">最新消息</TabsTrigger>
                  <TabsTrigger value="faq">常見問題</TabsTrigger>
                </TabsList>

                {/* Story */}
                <TabsContent value="story" className="mt-6">
                  <Card>
                    <CardContent className="pt-8 prose prose-slate max-w-none">
                      {project.story ? (
                        <Streamdown>{project.story}</Streamdown>
                      ) : project.description ? (
                        <p>{project.description}</p>
                      ) : (
                        <p className="text-muted-foreground">暫無專案故事</p>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>

                {/* Rewards */}
                <TabsContent value="rewards" className="mt-6">
                  {rewards.length > 0 ? (
                    <div className="space-y-4">
                      {rewards.map((reward: any, index: number) => (
                        <Card key={index}>
                          <CardContent className="pt-6">
                            <div className="flex justify-between items-start mb-3">
                              <h3 className="text-xl font-semibold">{reward.title}</h3>
                              <span className="text-2xl font-bold text-primary">
                                {formatAmount(reward.amount)}
                              </span>
                            </div>
                            <p className="text-muted-foreground mb-4">{reward.description}</p>
                            {reward.items && reward.items.length > 0 && (
                              <ul className="space-y-1 text-sm">
                                {reward.items.map((item: string, i: number) => (
                                  <li key={i} className="flex items-start">
                                    <span className="mr-2">•</span>
                                    <span>{item}</span>
                                  </li>
                                ))}
                              </ul>
                            )}
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  ) : (
                    <Card>
                      <CardContent className="pt-8 text-center text-muted-foreground">
                        暫無回饋方案
                      </CardContent>
                    </Card>
                  )}
                </TabsContent>

                {/* Updates */}
                <TabsContent value="updates" className="mt-6">
                  {updates.length > 0 ? (
                    <div className="space-y-4">
                      {updates.map((update: any, index: number) => (
                        <Card key={index}>
                          <CardContent className="pt-6">
                            <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                              <Calendar className="h-4 w-4" />
                              <span>{new Date(update.date).toLocaleDateString('zh-TW')}</span>
                            </div>
                            <h3 className="text-xl font-semibold mb-3">{update.title}</h3>
                            <div className="prose prose-slate max-w-none">
                              <Streamdown>{update.content}</Streamdown>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  ) : (
                    <Card>
                      <CardContent className="pt-8 text-center text-muted-foreground">
                        暫無最新消息
                      </CardContent>
                    </Card>
                  )}
                </TabsContent>

                {/* FAQ */}
                <TabsContent value="faq" className="mt-6">
                  {faq.length > 0 ? (
                    <Card>
                      <CardContent className="pt-6">
                        <Accordion type="single" collapsible className="w-full">
                          {faq.map((item: any, index: number) => (
                            <AccordionItem key={index} value={`item-${index}`}>
                              <AccordionTrigger>{item.question}</AccordionTrigger>
                              <AccordionContent>
                                <div className="prose prose-slate max-w-none">
                                  <Streamdown>{item.answer}</Streamdown>
                                </div>
                              </AccordionContent>
                            </AccordionItem>
                          ))}
                        </Accordion>
                      </CardContent>
                    </Card>
                  ) : (
                    <Card>
                      <CardContent className="pt-8 text-center text-muted-foreground">
                        暫無常見問題
                      </CardContent>
                    </Card>
                  )}
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
