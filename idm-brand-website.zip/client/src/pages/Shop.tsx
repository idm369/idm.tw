import { useState } from "react";
import { Link } from "wouter";
import { ShoppingCart, Eye } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { trpc } from "@/lib/trpc";

export default function Shop() {
  const [selectedCategory, setSelectedCategory] = useState<string | undefined>(undefined);
  
  const { data: products, isLoading } = trpc.product.list.useQuery({
    category: selectedCategory,
  });

  const categories = ["全部", "模組化產品", "工業設計", "創客工具", "配件"];

  const formatPrice = (price: number) => {
    return `NT$ ${(price / 100).toLocaleString('zh-TW')}`;
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1">
        {/* Hero Section */}
        <section className="bg-muted/30 py-16">
          <div className="container">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">線上商店</h1>
            <p className="text-xl text-muted-foreground max-w-2xl">
              選購我們精心設計的產品，體驗工業美學與實用性的完美結合
            </p>
          </div>
        </section>

        {/* Category Filter */}
        <section className="py-8 border-b border-border">
          <div className="container">
            <div className="flex flex-wrap gap-2">
              {categories.map((category) => (
                <Button
                  key={category}
                  variant={selectedCategory === (category === "全部" ? undefined : category) ? "default" : "outline"}
                  onClick={() => setSelectedCategory(category === "全部" ? undefined : category)}
                >
                  {category}
                </Button>
              ))}
            </div>
          </div>
        </section>

        {/* Products Grid */}
        <section className="py-16">
          <div className="container">
            {isLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {[...Array(8)].map((_, i) => (
                  <Card key={i} className="overflow-hidden">
                    <div className="aspect-square bg-muted animate-pulse" />
                    <CardContent className="pt-6">
                      <div className="h-6 bg-muted rounded mb-2 animate-pulse" />
                      <div className="h-4 bg-muted rounded w-2/3 animate-pulse" />
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : products && products.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {products.map((product) => {
                  const images = product.images ? JSON.parse(product.images) : [];
                  const coverImage = product.coverImage || (images.length > 0 ? images[0] : null);
                  const hasDiscount = product.originalPrice && product.originalPrice > product.price;
                  
                  return (
                    <Link key={product.id} href={`/shop/${product.slug}`}>
                        <Card className="overflow-hidden border-border hover:border-primary transition-all hover:shadow-lg h-full flex flex-col">
                          <div className="aspect-square bg-muted overflow-hidden relative">
                            {coverImage ? (
                              <img
                                src={coverImage}
                                alt={product.name}
                                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                              />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-primary/20 to-accent/20">
                                <ShoppingCart className="h-16 w-16 text-primary/40" />
                              </div>
                            )}
                            {product.stock === 0 && (
                              <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
                                <span className="text-white font-semibold text-lg">已售完</span>
                              </div>
                            )}
                          </div>
                          <CardContent className="pt-6 flex-1 flex flex-col">
                            <h3 className="text-lg font-semibold mb-2 group-hover:text-primary transition-colors line-clamp-2 flex-1">
                              {product.name}
                            </h3>
                            {product.description && (
                              <p className="text-muted-foreground text-sm mb-3 line-clamp-2">
                                {product.description}
                              </p>
                            )}
                            <div className="mt-auto">
                              <div className="flex items-baseline gap-2 mb-2">
                                <span className="text-xl font-bold text-primary">
                                  {formatPrice(product.price)}
                                </span>
                                {hasDiscount && (
                                  <span className="text-sm text-muted-foreground line-through">
                                    {formatPrice(product.originalPrice!)}
                                  </span>
                                )}
                              </div>
                              <div className="flex items-center justify-between text-sm text-muted-foreground">
                                {product.category && (
                                  <span className="px-2 py-1 bg-muted rounded text-xs">
                                    {product.category}
                                  </span>
                                )}
                                <div className="flex items-center gap-1">
                                  <Eye className="h-3 w-3" />
                                  <span className="text-xs">{product.viewCount || 0}</span>
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                    </Link>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-16">
                <p className="text-xl text-muted-foreground">目前沒有商品</p>
              </div>
            )}
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
