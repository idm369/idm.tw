import { useState } from "react";
import { Link } from "wouter";
import { Menu, X, ShoppingCart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { APP_TITLE } from "@/const";
import { useAuth } from "@/_core/hooks/useAuth";

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { user } = useAuth();
  
  // TODO: 實作購物車數量查詢
  const cartItemCount = 0;

  const navigation = [
    { name: "首頁", href: "/" },
    { name: "作品集", href: "/portfolio" },
    { name: "商店", href: "/shop" },
    { name: "募資項目", href: "/crowdfunding" },
    { name: "關於我們", href: "/about" },
    { name: "聯繫我們", href: "/contact" },
  ];

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <nav className="container flex h-16 items-center justify-between">
        {/* Logo */}
        <Link href="/">
          <a className="flex items-center space-x-2 text-foreground hover:text-primary transition-colors">
            <span className="text-xl font-bold tracking-tight">{APP_TITLE}</span>
          </a>
        </Link>

        {/* Desktop Navigation */}
        <div className="hidden md:flex md:items-center md:space-x-1">
          {navigation.map((item) => (
            <Link key={item.name} href={item.href}>
              <a className="px-3 py-2 text-sm font-medium text-foreground/80 hover:text-foreground hover:bg-muted rounded-sm transition-colors">
                {item.name}
              </a>
            </Link>
          ))}
        </div>

        {/* Right Actions */}
        <div className="flex items-center space-x-4">
          {/* Cart Icon */}
          <Link href="/cart">
            <a className="relative p-2 text-foreground/80 hover:text-foreground transition-colors">
              <ShoppingCart className="h-5 w-5" />
              {cartItemCount > 0 && (
                <span className="absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-primary text-xs text-primary-foreground">
                  {cartItemCount}
                </span>
              )}
            </a>
          </Link>

          {/* Admin Link */}
          {user?.role === "admin" && (
            <Link href="/admin">
              <Button variant="outline" size="sm">
                管理後台
              </Button>
            </Link>
          )}

          {/* Mobile Menu Button */}
          <button
            type="button"
            className="md:hidden p-2 text-foreground/80 hover:text-foreground"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </nav>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-border bg-background">
          <div className="container py-4 space-y-1">
            {navigation.map((item) => (
              <Link key={item.name} href={item.href}>
                <a
                  className="block px-3 py-2 text-base font-medium text-foreground/80 hover:text-foreground hover:bg-muted rounded-sm transition-colors"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  {item.name}
                </a>
              </Link>
            ))}
          </div>
        </div>
      )}
    </header>
  );
}
