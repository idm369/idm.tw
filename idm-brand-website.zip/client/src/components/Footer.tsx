import { Link } from "wouter";
import { APP_TITLE } from "@/const";

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="border-t border-border bg-muted/30">
      <div className="container py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">{APP_TITLE}</h3>
            <p className="text-sm text-muted-foreground">
              想像無限，勇於實踐
            </p>
            <p className="text-sm text-muted-foreground">
              創意，從「敢想」開始。每一個偉大的成就，都源於一個最初的點子。
            </p>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h4 className="text-sm font-semibold">快速連結</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/portfolio">
                  <a className="text-muted-foreground hover:text-foreground transition-colors">
                    作品集
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/shop">
                  <a className="text-muted-foreground hover:text-foreground transition-colors">
                    商店
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/crowdfunding">
                  <a className="text-muted-foreground hover:text-foreground transition-colors">
                    募資項目
                  </a>
                </Link>
              </li>
            </ul>
          </div>

          {/* About */}
          <div className="space-y-4">
            <h4 className="text-sm font-semibold">關於</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/about">
                  <a className="text-muted-foreground hover:text-foreground transition-colors">
                    關於我們
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/contact">
                  <a className="text-muted-foreground hover:text-foreground transition-colors">
                    聯繫我們
                  </a>
                </Link>
              </li>
            </ul>
          </div>

          {/* Social */}
          <div className="space-y-4">
            <h4 className="text-sm font-semibold">社群媒體</h4>
            <div className="flex space-x-4">
              {/* Placeholder for social media icons */}
              <p className="text-sm text-muted-foreground">敬請期待</p>
            </div>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-border">
          <p className="text-center text-sm text-muted-foreground">
            © {currentYear} {APP_TITLE}. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
