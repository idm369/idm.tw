import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean, decimal } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Portfolio/作品集
 */
export const portfolios = mysqlTable("portfolios", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  description: text("description"),
  content: text("content"), // 詳細內容 (支援 markdown)
  coverImage: text("coverImage"), // S3 URL
  images: text("images"), // JSON array of S3 URLs
  videoUrl: text("videoUrl"), // 影片連結
  category: varchar("category", { length: 100 }), // 分類
  tags: text("tags"), // JSON array of tags
  featured: boolean("featured").default(false), // 是否為精選
  published: boolean("published").default(true),
  viewCount: int("viewCount").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Portfolio = typeof portfolios.$inferSelect;
export type InsertPortfolio = typeof portfolios.$inferInsert;

/**
 * Products/商品
 */
export const products = mysqlTable("products", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  description: text("description"),
  content: text("content"), // 詳細說明
  price: int("price").notNull(), // 價格 (以分為單位)
  originalPrice: int("originalPrice"), // 原價
  coverImage: text("coverImage"), // S3 URL
  images: text("images"), // JSON array of S3 URLs
  category: varchar("category", { length: 100 }),
  tags: text("tags"), // JSON array
  stock: int("stock").default(0),
  sku: varchar("sku", { length: 100 }),
  specifications: text("specifications"), // JSON object
  featured: boolean("featured").default(false),
  published: boolean("published").default(true),
  viewCount: int("viewCount").default(0),
  soldCount: int("soldCount").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Product = typeof products.$inferSelect;
export type InsertProduct = typeof products.$inferInsert;

/**
 * Crowdfunding Projects/募資項目
 */
export const crowdfundingProjects = mysqlTable("crowdfunding_projects", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  subtitle: text("subtitle"),
  description: text("description"),
  story: text("story"), // 專案故事
  coverImage: text("coverImage"),
  images: text("images"), // JSON array
  videoUrl: text("videoUrl"),
  goalAmount: int("goalAmount").notNull(), // 目標金額 (以分為單位)
  currentAmount: int("currentAmount").default(0), // 當前金額
  backerCount: int("backerCount").default(0), // 贊助人數
  status: mysqlEnum("status", ["draft", "active", "funded", "completed", "cancelled"]).default("draft"),
  startDate: timestamp("startDate"),
  endDate: timestamp("endDate"),
  externalUrl: text("externalUrl"), // 外部募資平台連結
  rewards: text("rewards"), // JSON array of reward tiers
  updates: text("updates"), // JSON array of project updates
  faq: text("faq"), // JSON array of FAQs
  featured: boolean("featured").default(false),
  published: boolean("published").default(true),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CrowdfundingProject = typeof crowdfundingProjects.$inferSelect;
export type InsertCrowdfundingProject = typeof crowdfundingProjects.$inferInsert;

/**
 * Shopping Cart/購物車
 */
export const cartItems = mysqlTable("cart_items", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  productId: int("productId").notNull(),
  quantity: int("quantity").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CartItem = typeof cartItems.$inferSelect;
export type InsertCartItem = typeof cartItems.$inferInsert;

/**
 * Orders/訂單
 */
export const orders = mysqlTable("orders", {
  id: int("id").autoincrement().primaryKey(),
  orderNumber: varchar("orderNumber", { length: 100 }).notNull().unique(),
  userId: int("userId").notNull(),
  status: mysqlEnum("status", ["pending", "paid", "processing", "shipped", "delivered", "cancelled"]).default("pending"),
  totalAmount: int("totalAmount").notNull(), // 總金額 (以分為單位)
  items: text("items").notNull(), // JSON array of order items
  shippingAddress: text("shippingAddress"), // JSON object
  contactInfo: text("contactInfo"), // JSON object
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Order = typeof orders.$inferSelect;
export type InsertOrder = typeof orders.$inferInsert;

/**
 * Contact Form Submissions/聯繫表單
 */
export const contactSubmissions = mysqlTable("contact_submissions", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  subject: varchar("subject", { length: 255 }),
  message: text("message").notNull(),
  status: mysqlEnum("status", ["new", "read", "replied"]).default("new"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ContactSubmission = typeof contactSubmissions.$inferSelect;
export type InsertContactSubmission = typeof contactSubmissions.$inferInsert;
