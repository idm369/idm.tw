import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  portfolio: router({
    list: publicProcedure
      .input(z.object({
        category: z.string().optional(),
        limit: z.number().optional(),
      }).optional())
      .query(async ({ input }) => {
        return await db.getPublishedPortfolios(input?.category, input?.limit);
      }),
    
    featured: publicProcedure
      .input(z.object({
        limit: z.number().default(6),
      }).optional())
      .query(async ({ input }) => {
        return await db.getFeaturedPortfolios(input?.limit);
      }),
    
    getBySlug: publicProcedure
      .input(z.object({
        slug: z.string(),
      }))
      .query(async ({ input }) => {
        return await db.getPortfolioBySlug(input.slug);
      }),
  }),

  product: router({
    list: publicProcedure
      .input(z.object({
        category: z.string().optional(),
        limit: z.number().optional(),
      }).optional())
      .query(async ({ input }) => {
        return await db.getPublishedProducts(input?.category, input?.limit);
      }),
    
    featured: publicProcedure
      .input(z.object({
        limit: z.number().default(6),
      }).optional())
      .query(async ({ input }) => {
        return await db.getFeaturedProducts(input?.limit);
      }),
    
    getBySlug: publicProcedure
      .input(z.object({
        slug: z.string(),
      }))
      .query(async ({ input }) => {
        return await db.getProductBySlug(input.slug);
      }),
  }),

  crowdfunding: router({
    list: publicProcedure
      .input(z.object({
        limit: z.number().optional(),
      }).optional())
      .query(async ({ input }) => {
        return await db.getPublishedCrowdfundingProjects(input?.limit);
      }),
    
    getBySlug: publicProcedure
      .input(z.object({
        slug: z.string(),
      }))
      .query(async ({ input }) => {
        return await db.getCrowdfundingProjectBySlug(input.slug);
      }),
  }),

  contact: router({
    submit: publicProcedure
      .input(z.object({
        name: z.string().min(1),
        email: z.string().email(),
        subject: z.string().optional(),
        message: z.string().min(1),
      }))
      .mutation(async ({ input }) => {
        await db.createContactSubmission(input);
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
