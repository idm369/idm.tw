import { eq, desc, and, like, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, portfolios, InsertPortfolio, products, InsertProduct, crowdfundingProjects, InsertCrowdfundingProject, cartItems, InsertCartItem, orders, InsertOrder, contactSubmissions, InsertContactSubmission } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Portfolio queries
export async function getPublishedPortfolios(category?: string, limit?: number) {
  const db = await getDb();
  if (!db) return [];

  const conditions = [eq(portfolios.published, true)];
  if (category) {
    conditions.push(eq(portfolios.category, category));
  }

  let query = db.select().from(portfolios).where(and(...conditions)).orderBy(desc(portfolios.createdAt));
  
  if (limit) {
    query = query.limit(limit) as any;
  }

  return await query;
}

export async function getFeaturedPortfolios(limit: number = 6) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(portfolios)
    .where(and(eq(portfolios.published, true), eq(portfolios.featured, true)))
    .orderBy(desc(portfolios.createdAt))
    .limit(limit);
}

export async function getPortfolioBySlug(slug: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(portfolios).where(eq(portfolios.slug, slug)).limit(1);
  
  // Increment view count
  if (result.length > 0) {
    await db.update(portfolios)
      .set({ viewCount: sql`${portfolios.viewCount} + 1` })
      .where(eq(portfolios.id, result[0].id));
  }

  return result.length > 0 ? result[0] : undefined;
}

export async function createPortfolio(portfolio: InsertPortfolio) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(portfolios).values(portfolio);
  return result;
}

export async function updatePortfolio(id: number, portfolio: Partial<InsertPortfolio>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(portfolios).set(portfolio).where(eq(portfolios.id, id));
}

export async function deletePortfolio(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.delete(portfolios).where(eq(portfolios.id, id));
}

// Product queries
export async function getPublishedProducts(category?: string, limit?: number) {
  const db = await getDb();
  if (!db) return [];

  const conditions = [eq(products.published, true)];
  if (category) {
    conditions.push(eq(products.category, category));
  }

  let query = db.select().from(products).where(and(...conditions)).orderBy(desc(products.createdAt));
  
  if (limit) {
    query = query.limit(limit) as any;
  }

  return await query;
}

export async function getFeaturedProducts(limit: number = 6) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(products)
    .where(and(eq(products.published, true), eq(products.featured, true)))
    .orderBy(desc(products.createdAt))
    .limit(limit);
}

export async function getProductBySlug(slug: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(products).where(eq(products.slug, slug)).limit(1);
  
  // Increment view count
  if (result.length > 0) {
    await db.update(products)
      .set({ viewCount: sql`${products.viewCount} + 1` })
      .where(eq(products.id, result[0].id));
  }

  return result.length > 0 ? result[0] : undefined;
}

// Crowdfunding queries
export async function getPublishedCrowdfundingProjects(limit?: number) {
  const db = await getDb();
  if (!db) return [];

  let query = db.select().from(crowdfundingProjects)
    .where(eq(crowdfundingProjects.published, true))
    .orderBy(desc(crowdfundingProjects.createdAt));
  
  if (limit) {
    query = query.limit(limit) as any;
  }

  return await query;
}

export async function getCrowdfundingProjectBySlug(slug: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(crowdfundingProjects).where(eq(crowdfundingProjects.slug, slug)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// Cart queries
export async function getCartItems(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(cartItems).where(eq(cartItems.userId, userId));
}

export async function addToCart(item: InsertCartItem) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Check if item already exists
  const existing = await db.select().from(cartItems)
    .where(and(eq(cartItems.userId, item.userId), eq(cartItems.productId, item.productId)))
    .limit(1);

  if (existing.length > 0) {
    // Update quantity
    await db.update(cartItems)
      .set({ quantity: sql`${cartItems.quantity} + ${item.quantity}` })
      .where(eq(cartItems.id, existing[0].id));
  } else {
    await db.insert(cartItems).values(item);
  }
}

export async function updateCartItemQuantity(id: number, quantity: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(cartItems).set({ quantity }).where(eq(cartItems.id, id));
}

export async function removeFromCart(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.delete(cartItems).where(eq(cartItems.id, id));
}

export async function clearCart(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.delete(cartItems).where(eq(cartItems.userId, userId));
}

// Order queries
export async function createOrder(order: InsertOrder) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(orders).values(order);
  return result;
}

export async function getOrdersByUserId(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(orders).where(eq(orders.userId, userId)).orderBy(desc(orders.createdAt));
}

// Contact submission queries
export async function createContactSubmission(submission: InsertContactSubmission) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(contactSubmissions).values(submission);
  return result;
}

export async function getContactSubmissions() {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(contactSubmissions).orderBy(desc(contactSubmissions.createdAt));
}
